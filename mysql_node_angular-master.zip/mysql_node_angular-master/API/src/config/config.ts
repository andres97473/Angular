export default {
  jwtSecret: 'BDPEK@'
};
